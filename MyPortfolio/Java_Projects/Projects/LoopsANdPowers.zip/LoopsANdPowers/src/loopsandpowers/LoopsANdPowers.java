/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loopsandpowers;
import java.util.Scanner;
/**
 *
 * @author westy
 */
public class LoopsANdPowers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner Sc = new Scanner (System.in);
        
        int Choice = 0;
        int UserNum;
        int Answer;
        int Exponent;
        
            while (Choice != 4){
                System.out.println("------Epic Exponent Calculator------");
                System.out.println("1... Find the value of a Number Squared");
                System.out.println("2... Find the value of a number Cubed");
                System.out.println("3... Find a value to any number, to any Power");
                System.out.println("4... Exit");
                Choice = Sc.nextInt();
             
                if (Choice == 1){
                    System.out.println("What number would you like to Square?");
                    UserNum = Sc.nextInt();
                    Answer = UserNum*UserNum;
                    System.out.println("The Answer is " + Answer);
                }
                
                else if (Choice == 2){
                    System.out.println("What number would you like to Cube?");
                    UserNum = Sc.nextInt();
                    Answer = (UserNum*UserNum*UserNum);
                    System.out.println("The answer is " + Answer);
            
                }
                
                else if (Choice ==  3){
                    System.out.println("What is the base number you would like to use?");
                    UserNum = Sc.nextInt();
                    System.out.print("What is the power you would like to use? \n");
                    Exponent = Sc.nextInt();
                    Answer = (int)(Math.pow(UserNum, Exponent));
                    System.out.println("The answer is " + Answer);
                    
                }
                
                else if (Choice == 4){
                    System.out.println(" ----------Ending Program-------- ");    
                }
                    
            
                else {
                    System.out.println("That's not a valid answer!");
                }
                    
            }
    }
    
}
