/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package variables.and.variable.types;

/**
 *
 * @author westy
 */
public class VariablesAndVariableTypes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int age = 43;
        double hieght = 71.56;
        String address =  "433 Thompson street";
        boolean deaf = true;
        
       System.out.println("Mr. Smiles is " + age + "years old." );
       System.out.println("Mr. Smiles is " + hieght + " inches tall.");
       System.out.println("Mr. Smiles lives at " + address + ".");
      
        if(deaf == true){ 
        System.out.println("Mr. Smiles is deaf.");
        }
        else{
            System.out.println("Mr.Smiles is NOT Deaf.");
        }
    }
}
        
        
       
            

                
               
        
                
                
        
        
                
                
        
                
        
        
        
        
        
    
    

